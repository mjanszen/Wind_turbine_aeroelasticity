# WTA-course
Classical BEM codes for master's course 'Wind turbine aeroelasticity' @ TU Delft
