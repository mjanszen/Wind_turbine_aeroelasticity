This folder stores the aerodynamic coefficient data of airfoils. Please save them in order according to their numbers
