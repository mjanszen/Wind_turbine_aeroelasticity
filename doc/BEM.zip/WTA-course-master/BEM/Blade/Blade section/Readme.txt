Number the cross-sectional slices of the blades and write their corresponding airfoil numbers in 'Blade section.dat'

